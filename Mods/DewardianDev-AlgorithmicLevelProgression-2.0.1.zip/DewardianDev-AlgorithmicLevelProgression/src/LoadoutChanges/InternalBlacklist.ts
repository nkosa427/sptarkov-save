export default [
    "544a3f024bdc2d1d388b4568", //ELCAN Specter OS4x assault scope
    ///
    "5af99e9186f7747c447120b8", // Bad pockets
    "60c7272c204bc17802313365",
    "627a4e6b255f7527fb05a0f6",
    "64cbd95a29b9b4283e216ff5",
    ///
    "622b4f54dc8dcc0ba8742f85", //HK G36 Hensoldt HKV ZF 1.5x carry handle
    "622b4d7df9cfc87d675d2ded", //HK G36 Hensoldt HKV 3x carry handle
    // armasight vulcan universal base
    // Geissele Super Precision 30mm
    "5aa66a9be5b5b0214e506e89", //Nightforce Magmount 34mm ring scope mount > stupid long scope mount
    "5a1ead28fcdbcb001912fa9f", // Reap-ir Mount
    "5c86592b2e2216000e69e77c", // IEA Mil-Optics KH/F 34mm one-piece magmount <Stupid Long distance scopes>
    "5c11046cd174af02a012e42b", // Wilcox Interface for PVS-7 >  Thermal night vision connector
    "5ea058e01dbce517f324b3e2", // Tac-Kek Heavy Trooper mask for Ops-Core-type helmets
    "5c0558060db834001b735271",// GPNVG-18 Night Vision goggles
    "5648b62b4bdc2d9d488b4585",// gp-34
    "5e99711486f7744bfc4af328",// Sanitarsmedkit
    "5d52cc5ba4b9367408500062",
    "6087e570b998180e9f76dc24",
    "58ac60eb86f77401897560ff",// golden balaclava!
    "6241c316234b593b5676b637",// bb ammo
    "5cdeb229d7f00c000e7ce174",// stationary gun
    "5943d9c186f7745a13413ac9",// shrapnel bullets?
    "5996f6cb86f774678763a6ca",// shrapnel bullets?
    "5996f6fc86f7745e585b4de3",// shrapnel bullets?
    "63b35f281745dd52341e5da7",// shrapnel bullets?
    "5d2f2ab648f03550091993ca",// shrapnel bullets?
    "5cde8864d7f00c0010373be1",
    "64b9cf0ac12b9c38db26923a",// << no idea
    "627a137bf21bc425b06ab944",
    "610720f290b75a49ff2e5e25",
    "5996f6d686f77467977ba6cc",// shrapnel bullets?
    "5ae083b25acfc4001a5fc702",// Master hand ?
    "544a3d0a4bdc2d1b388b4567",
    "5a16bb52fcdbcb001a3b00dc",// skull lock
    "5a1eaa87fcdbcb001865f75e",// reap-ir
    "5d1b5e94d7ad1a2b865a96b0",// flir
    "5c066ef40db834001966a595",// helmet_armasight_nvg_googles_mask
    '5a0c59791526d8dba737bba7',// butt pad
    "57371aab2459775a77142f22",
    //small mags 
    "57838f0b2459774a256959b2",
    "5aaa5e60e5b5b000140293d6",
    "5b1fd4e35acfc40018633c39",
    "59e5d83b86f7745aed03d262",
    "5b7bef1e5acfc43d82528402",
    "617130016c780c1e710c9a24",
    "55d4837c4bdc2d1d4e8b456c",
    "5c503ac82e221602b21d6e9a",
    "6241c2c2117ad530666a5108",
    //large mags
    // "55d485804bdc2d8c2f8b456b", shotgun 153/155 extended /7/8
    // "56deeefcd2720bc8328b4568", shotgun 153/155 extended /7/8
    // "5882163224597757561aa920", shotgun 153/155 extended /7/8
    "5a78832ec5856700155a6ca3",
    "5a966f51a2750c00156aacf6",
    "5cf8f3b0d7f00c00217872ef",
    "625ff2eb9f5537057932257d",
    "625ff3046d721f05d93bf2ee",
    "625ff31daaaa8c1130599f64",
    "627bce33f21bc425b06ab967",
    '564ca9df4bdc2d35148b4569',
    // '55d481904bdc2d8c2f8b456a', //45 round ak
    '55d482194bdc2d1d4e8b456b',
    '5bed625c0db834001c062946',
    '55d485be4bdc2d962f8b456f',
    '5cbdc23eae9215001136a407',
    '5c6175362e221600133e3b94',
    '5cfe8010d7ad1a59283b14c6',
    '61695095d92c473c7702147a',
    '61695095d92c473c7702147a',
    '59c1383d86f774290a37e0ca',
    '5c6592372e221600133e47d7',
    '544a37c44bdc2d25388b4567',
    '5a718f958dc32e00094b97e7',
    '5c5db6742e2216000f1b2852',
    '5a351711c4a282000b1521a4',
    '5addccf45acfc400185c2989',
    '5b7bef9c5acfc43d102852ec',
    // "5b1fb3e15acfc4001637f068", 40 round ak
    // "59e5f5a486f7746c530b3ce2", 40 round
    // "544a378f4bdc2d30388b4567", 40 round
    // "5d1340bdd7ad1a0e8d245aab", 40-round 556 45
    "630e295c984633f1fb0e7c30",
    // "5ba26586d4351e44f824b340", MP7 40 
    "5c5db6652e221600113fba51",
    "5cffa483d7ad1a049e54ef1c",
    "5d52d479a4b936793d58c76b",
    // stm-9
    // stocks
    "5c0faeddd174af02a962601f",
    "5d120a10d7ad1a4e1026ba85",
    "5b0800175acfc400153aebd4",
    "5947e98b86f774778f1448bc",
    "5947eab886f77475961d96c5",
    // "602e3f1254072b51b239f713",
    "5c793fb92e221644f31bfb64",
    "5c793fc42e221600114ca25d",
    "591aef7986f774139d495f03",
    "591af10186f774139d495f0e",
    "627254cc9c563e6e442c398f",
    "638de3603a1a4031d8260b8c",
    "5a33ca0fc4a282000d72292f",
    // Saiga-9 9x19 carbine
    // stocks
    "5cf50fc5d7f00c056c53f83c", //AK-74M CAA AKTS AK74 buffer tube > 25
    "5ac78eaf5acfc4001926317a", //AK-74M/AK-100 Zenit PT Lock >2
    //Full Size AK mods
    // stocks
    // "628a6678ccaab13006640e49", //AKM/AK-74 RD AK to M4 buffer tube adapter > 17
    "5b222d335acfc4771e1be099", //AKM/AK-74 Zenit PT Lock > 1
    "59ecc28286f7746d7a68aa8c", // AK-74U Zenit PT Lock > 1
    "5839a40f24597726f856b511", // bufferTubes > 21
    "5cf518cfd7f00c065b422214",
    "5649b2314bdc2d79388b4576",
    "5b04473a5acfc40018632f70", //beefy Stock
    "5e217ba4c1434648c13568cd", //Red funky stock
    "5b0e794b5acfc47a877359b2", // Zhokov black 
    "6087e2a5232e5a31c233d552", //Archangel 
    //DustCovers 
    "59d6507c86f7741b846413a2", // AKM dust cover (6P1 0-1) allowing one
    "59e6449086f7746c9f75e822",
    "628a665a86cbd9750d2ff5e5",
    "5649af094bdc2df8348b4586",
    "5ac50da15acfc4001718d287",
    //bullets that think they are guns
    "624c0b3340357b5f566e8766",
    "624c0b3340357b5f566e8766",
    "6217726288ed9f0845317459",
    "62178be9d0050232da3485d9",
    //Mosin shorty,
    "5bfd36ad0db834001c38ef66",
    "5bfd36290db834001966869a",
    "5a16b9fffcdbcb0176308b34",
    "5c07c9660db834001a66b588",
    "5d2f25bc48f03502573e5d85",
    "5a7c74b3e899ef0014332c29",
    //Waffle 545
    "615d8f8567085e45ef1409ca",
    //Mosin stocks
    "5bbdb870d4351e00367fb67d",
    "5bae13bad4351e00320204af",
    //IR lasers
    "57fd23e32459772d0805bcf1",
    "544909bb4bdc2d6f028b4577",
    "5d10b49bd7ad1a1a560708b0",
    "5c06595c0db834001a66af6c",
    "5c5952732e2216398b5abda2",
    "5a5f1ce64f39f90b401987bc",
    "61605d88ffa6e502ac5e7eeb",
    //pistolGrips
    "5b07db875acfc40dc528a5f6",
    "615d8faecabb9b7ad90f4d5d",
    "59db3acc86f7742a2c4ab912",
    "59db3b0886f77429d72fb895",
    "59db3a1d86f77429e05b4e92",
    "5d025cc1d7ad1a53845279ef",
    "5f6341043ada5942720e2dc5",
    "6087e663132d4d12c81fd96b",
    "5e2192a498a36665e8337386",
    "5cf54404d7f00c108840b2ef",
    "5b30ac585acfc433000eb79c",
    "628a664bccaab13006640e47",
    "628c9ab845c59e5b80768a81",
    "5c6bf4aa2e2216001219b0ae",
    "5649ae4a4bdc2d1b2b8b4588",
    "6113c3586c780c1e710c90bc",
    "6113cce3d92c473c770200c7",
    "6113cc78d3a39d50044c065a",
    "5b7d679f5acfc4001a5c4024",
    //Handguards
    "595cfa8b86f77427437e845b",
    "595cf16b86f77427440c32e2",
    "55f84c3c4bdc2d5f408b4576",
    "5c9a25172e2216000f20314e",
    "619b5db699fb192e7430664f",
    "5b2cfa535acfc432ff4db7a0",
    "5c9a25172e2216000f20314e",
    "55f84c3c4bdc2d5f408b4576",
    "588b56d02459771481110ae2",
    "5c9a26332e2216001219ea70",
    "5ea16ada09aa976f2e7a51be",
    "5ea16acdfadf1d18c87b0784",
    "5d4405f0a4b9361e6a4e6bd9",
    "5c78f2492e221600114c9f04",
    "5c78f2612e221600114c9f0d",
    "6034e3e20ddce744014cb878",
    "6034e3d953a60014f970617b",
    "6034e3cb0ddce744014cb870",
    "5c6d5d8b2e221644fc630b39",
    "5d00e0cbd7ad1a6c6566a42d",
    "5d00f63bd7ad1a59283b1c1e",
    "6087e0336d0bd7580617bb7a",
    "63888bbd28e5cc32cc09d2b6",
    //Foregrips
    "5fc0f9b5d724d907e2077d82",
    "5cda9bcfd7f00c0c0b53e900",
    "59f8a37386f7747af3328f06",
    "5a7dbfc1159bd40016548fde",
    "619386379fb0c665d5490dbe",
    "5de8fbad2fbe23140d3ee9c4",
    "5b057b4f5acfc4771e1bd3e9",
    "5c791e872e2216001219c40a",
    "5f6340d3ca442212f4047eb2",
    "591af28e86f77414a27a9e1d",
    "5c1bc5612e221602b5429350",
    "5c1cd46f2e22164bef5cfedb",
    "5c1bc5af2e221602b412949b",
    //long handgun stock
    "5d1c702ad7ad1a632267f429",

    "620109578d82e67e7911abf2",// signal pistol
    "62178c4d4ecf221597654e3d",
    "62389aaba63f32501b1b444f",// signal ammo
    "62389ba9a63f32501b1b4451",
    "62389bc9423ed1685422dc57",
    "62389be94d5d474bf712e709",
    "635267f063651329f75a4ee8"
]