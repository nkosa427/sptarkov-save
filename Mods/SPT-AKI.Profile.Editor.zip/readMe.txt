SPT-AKI Profile Editor Version 2.8.6 for server SPT-AKI 3.7.0 - 3.7.6
https://github.com/SkiTles55/SPT-AKI-Profile-Editor

Discord server for discussion and paid support from the developer - https://discord.gg/NTwSA4AfRP

To install run setup.exe

Changes:
Fixed an error parsing the status of the quest "AvailableAfter"

Support the developer:
https://yoomoney.ru/to/410015658095326
Steam Trade Offer Link
https://steamcommunity.com/tradeoffer/new/?partner=350485380%26token=zCrhUwxR
LTC wallet
MNtz8Zz1cPD1CZadoc38jT5qeqeFBS6Aif

Submit a bug report \ Feature request
https://github.com/SkiTles55/SPT-AKI-Profile-Editor/issues/new/choose

Frequently asked questions - https://github.com/SkiTles55/SPT-AKI-Profile-Editor/blob/master/ENGFAQ.md
Using a helper mod - https://github.com/SkiTles55/SPT-AKI-Profile-Editor/blob/master/Guidelines/ModHelperENG.md

