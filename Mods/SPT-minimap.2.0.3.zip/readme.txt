Copy BepInEx folder into your SPT folder
Do NOT copy the Minimap folder into your SPT folder

If you have an older version installed, 
remove CactusPie.MapLocation.dll 
from BepInEx\plugins in your SPT installation