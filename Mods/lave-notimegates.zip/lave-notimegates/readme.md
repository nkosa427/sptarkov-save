# lave-removetimegates

This mod will remove all quest timegates so you can slam out all the quests in one go!

### Install

To install simply copy paste the foler `lave-notimegates` into your `user/mods/` folder
