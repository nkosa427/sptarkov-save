# @pnpm/exe

## 7.1.8

### Patch Changes

- 7fb1ac0e4: Fix pre-compiled pnpm binaries crashing when NODE_MODULES is set.

## 6.19.0

### Minor Changes

- b6d74c545: Allow a system's package manager to override pnpm's default settings
